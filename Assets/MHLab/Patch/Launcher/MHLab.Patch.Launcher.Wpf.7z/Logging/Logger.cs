﻿using Serilog;
using System;
using System.IO;
using System.Runtime.CompilerServices;
using ILogger = MHLab.Patch.Core.Logging.ILogger;

namespace MHLab.Patch.Launcher.Wpf.Logging
{
    public sealed class Logger : ILogger
    {
        private bool _isDebug;
        
        public Logger(string logfilePath, bool isDebug)
        {
            _isDebug = isDebug;
            
            var configuration = new LoggerConfiguration();
            if (isDebug)    
                configuration.MinimumLevel.Debug();
            else
                configuration.MinimumLevel.Information();
            
            configuration.WriteTo.File(logfilePath, rollingInterval: RollingInterval.Day, shared: true);
            
            Log.Logger = configuration.CreateLogger();
        }

        public void Debug(string messageTemplate, [CallerFilePath] string callerPath = "", [CallerLineNumber] long callerLine = 0, [CallerMemberName] string callerMember = "")
        {
            Log.Debug(BuildMessage(messageTemplate, callerPath, callerLine, callerMember));
        }

        public void Info(string messageTemplate, [CallerFilePath] string callerPath = "", [CallerLineNumber] long callerLine = 0, [CallerMemberName] string callerMember = "")
        {
            Log.Information(BuildMessage(messageTemplate, callerPath, callerLine, callerMember));
        }

        public void Warning(string messageTemplate, [CallerFilePath] string callerPath = "", [CallerLineNumber] long callerLine = 0, [CallerMemberName] string callerMember = "")
        {
            Log.Warning(BuildMessage(messageTemplate, callerPath, callerLine, callerMember));
        }

        public void Error(Exception exception, string messageTemplate, [CallerFilePath] string callerPath = "", [CallerLineNumber] long callerLine = 0, [CallerMemberName] string callerMember = "")
        {
            Log.Error(exception, BuildMessage(messageTemplate, callerPath, callerLine, callerMember));
        }

        private string BuildMessage(string messageTemplate, string callerPath, long callerLine, string callerMember)
        {
            if (_isDebug)
            {
                var caller = Path.GetFileName(callerPath);
                messageTemplate = $"[{caller}::{callerMember}@{callerLine}] {messageTemplate}";
            }
            return messageTemplate;
        }
    }
}
