﻿using MHLab.Patch.Admin.Localization;
using MHLab.Patch.Admin.Logging;
using MHLab.Patch.Admin.Serializing;
using MHLab.Patch.Core.Admin;
using MHLab.Patch.Core.Admin.Localization;
using MHLab.Patch.Core.Admin.Progresses;
using MHLab.Patch.Core.IO;
using MHLab.Patch.Core.Versioning;
using System;
using System.IO;
using System.Reflection;

namespace MHLab.Patch.Admin
{
    public class AdminCommandLine
    {
        private readonly IAdminLocalizedMessages _localization;
        private readonly IAdminSettings _settings;
        private readonly Progress<BuilderProgress> _progress;

        public AdminCommandLine()
        {
            _settings = new AdminSettings()
            {
                RootPath = FilesManager.SanitizePath(Directory.GetCurrentDirectory()),
                AppDataPath = FilesManager.SanitizePath(PathsManager.Combine(PathsManager.GetSpecialPath(Environment.SpecialFolder.ApplicationData), "PATCH Admin Tool"))
            };
            _localization = new EnglishAdminLocalizedMessages();

            _progress = new Progress<BuilderProgress>();
            _progress.ProgressChanged += ProgressChanged;
        }

        public void Handle(string[] args)
        {
            switch (args[0])
            {
                case "--init":
                    HandleInitCommand(args);
                    break;
                case "--build":
                    HandleBuildCommand(args);
                    break;
                case "--getVersions":
                    HandleGetVersionsCommand(args);
                    break;
                case "--patch":
                    HandlePatchCommand(args);
                    break;
                case "--patcherUpdate":
                    HandlePatcherUpdateCommand(args);
                    break;
            }
        }

        private void ProgressChanged(object sender, BuilderProgress e)
        {
            Console.WriteLine($"{e.StepMessage} [{e.CurrentSteps}/{e.TotalSteps}]");
        }

        private void HandleInitCommand(string[] args)
        {
            DirectoriesManager.Create(_settings.GetApplicationFolderPath());
            DirectoriesManager.Create(_settings.GetUpdaterFolderPath());
        }

        private void HandleBuildCommand(string[] args)
        {
            var context = new AdminBuildContext(_settings, _progress)
            {
                Serializer = new NewtonsoftSerializer(),
                Logger = new Logger(_settings.GetLogsFilePath(), _settings.DebugMode),
            };

            var lastVersion = context.GetLastVersion();
            IVersion newVersion;

            if (lastVersion == null) newVersion = context.VersionFactory.Create();
            else
            {
                newVersion = context.VersionFactory.Create(lastVersion);
                var releaseType = string.Empty;
                if (args.Length > 1) releaseType = args[1].ToLower();

                switch(releaseType)
                {
                    case "major":
                        newVersion.UpdateMajor();
                        break;
                    case "minor":
                        newVersion.UpdateMinor();
                        break;
                    default:
                        newVersion.UpdatePatch();
                        break;
                }
            }

            context.BuildVersion = newVersion;
            context.LocalizedMessages = _localization;

            context.Initialize();

            var builder = new BuildBuilder(context);
            builder.Build();
        }

        private void HandleGetVersionsCommand(string[] args)
        {
            var context = new AdminPatchContext(_settings, _progress)
            {
                Serializer = new NewtonsoftSerializer(),
                Logger = new Logger(_settings.GetLogsFilePath(), _settings.DebugMode)
            };

            var versions = context.GetVersions();

            Console.WriteLine(context.Serializer.Serialize(versions));
        }

        private void HandlePatchCommand(string[] args)
        {
            var context = new AdminPatchContext(_settings, _progress)
            {
                Serializer = new NewtonsoftSerializer(),
                Logger = new Logger(_settings.GetLogsFilePath(), _settings.DebugMode)
            };

            var versions = context.GetVersions();

            if (versions.Count < 2) throw new Exception();

            var last = versions[versions.Count - 1];
            var previous = versions[versions.Count - 2];

            if (args.Length >= 3)
            {
                last = context.VersionFactory.Parse(args[2]);
                previous = context.VersionFactory.Parse(args[1]);
            }

            context.LocalizedMessages = _localization;
            context.VersionFrom = previous;
            context.VersionTo = last;
            context.CompressionLevel = 8;

            context.Initialize();

            var builder = new PatchBuilder(context);
            builder.Build();
        }

        private void HandlePatcherUpdateCommand(string[] args)
        {
            var launcherArchiveName = "MyLauncher";
            var compressionLevel = 5;

            if (args.Length > 1) launcherArchiveName = args[1];
            if (args.Length > 2) compressionLevel = Math.Clamp(int.Parse(args[2]), 1, 9);

            var context = new AdminPatcherUpdateContext(_settings, _progress)
            {
                Serializer = new NewtonsoftSerializer(),
                Logger = new Logger(_settings.GetLogsFilePath(), _settings.DebugMode),
                CompressionLevel = compressionLevel, 
                LauncherArchiveName = launcherArchiveName
            };
            
            context.LocalizedMessages = _localization;
            
            context.Initialize();

            var builder = new UpdaterBuilder(context);
            builder.Build();
        }
    }
}
